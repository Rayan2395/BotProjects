﻿//System related dlls
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.ServiceModel.Description;



//Microsoft related dlls
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;

namespace RKY_AutoPluginReg
{
    public class RKY_APRT
    {

        private static StreamWriter sw;


        static void Main(string[] args)
        {
          
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Console.WriteLine("Establishing Connection...");

            //CrmServiceClient client = new CrmServiceClient(@"AuthType=Office365;Url=https://itc05.crm.dynamics.com/;Username=solutiontest@ITC05.onmicrosoft.com;Password=Login@123");
            //IOrganizationService service = (IOrganizationService)client.OrganizationWebProxyClient != null ? (IOrganizationService)client.OrganizationWebProxyClient : (IOrganizationService)client.OrganizationServiceProxy;
            //IOrganizationService service = (IOrganizationService)client.OrganizationServiceProxy;

            // Connection Type-2
            //var connectionString = @"AuthType = Office365; Url=https://itc05.crm.dynamics.com/;Username=solutiontest@ITC05.onmicrosoft.com;Password=Login@123";
            //CrmServiceClient conn = new CrmServiceClient(connectionString);
            //IOrganizationService service;
            var service = LoginToCrm();//(IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;
            string fileName = System.IO.Path.GetFullPath(@"..\..\") + "Log.txt";
            //System.IO.DirectoryInfo[] dirInfos = dirInfo.GetDirectories("*.*");
            string currentDirName = System.IO.Directory.GetCurrentDirectory();

            if (File.Exists(fileName))
            {
                File.Delete(fileName);
            }

            // Create a new file     
            using (sw = new StreamWriter(File.Create(fileName)))
            {
                Console.WriteLine("Log file create with name Log");
                sw.WriteLine("New file created: {0}", DateTime.Now.ToString());
                Console.WriteLine("For more detail and audit kindly view Log.txt file");
                // sw = createLogFile(path2);
                if (service != null)
                {
                    Console.WriteLine("Succesfully Connected to crm system..");
                    sw.WriteLine("Succesfully Connected to crm system..");
                }
                else
                    return;
                sw.Write("\n");

                string filePath = "";
                var assembly = Assembly.LoadFile(filePath);
                Type[] types = GetPluginTypes(assembly);

                Type assemblyType = (System.Type)types[0];

                Guid assemblyId = RegisterAssembly(service, assembly, filePath, assemblyType);


                int count = 1;

                foreach (var type in types)
                {
                    string p = type.Name;
                    string[] pro = assembly.GetName().FullName.Split(",=".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);


                    Guid pluginTypeId = RegisterPlugin(service, assemblyId, assembly, type, count);
                    RegisterPluginStep(service, pluginTypeId, assembly, type);
                    count++;
                }
                Console.WriteLine("Succesfully completed");
                sw.WriteLine("Succesfully completed");
                Console.ReadLine();
            }


        }
        public static Guid RegisterAssembly(IOrganizationService Service, Assembly Assembly, string filePath, Type assemblyType)
        {
            sw.WriteLine("\r\n");
            sw.WriteLine("------------Assembly-------------");
            string startupPath = System.IO.Directory.GetCurrentDirectory();
            Guid assemblyId = Guid.Empty;
            try
            {
                var assembly = Assembly;
                string[] props = assembly.GetName().FullName.Split(",=".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                string isAssemblyNameExist = props[0];
                sw.WriteLine("Assembly name: {0}", isAssemblyNameExist);
                sw.WriteLine("Checking if Assembly already present in the system");
                Entity isAssembly = IsPluginAssemblyExists(Service, isAssemblyNameExist);

                Type t = assembly.GetType(assemblyType.FullName);
                System.Reflection.MemberInfo info = t;
                var attributes = info.GetCustomAttributesData();
                if (isAssembly == null)
                {
                    sw.WriteLine("Creating Assembly with below details: ");
                    sw.WriteLine("Updating the Assembly with below detail: ");
                    sw.WriteLine("Name: " + props[0].ToString());
                    sw.WriteLine("Version: " + props[2].ToString());
                    sw.WriteLine("IsolationMode: " + attributes[0].ConstructorArguments[7].Value.ToString());
                    sw.WriteLine("Publickeytoken: " + props[6].ToString());

                    Entity assemb = new Entity("pluginassembly");
                    assemb["name"] = props[0];
                    assemb["culture"] = props[4];
                    assemb["version"] = props[2];
                    assemb["publickeytoken"] = props[6];
                    assemb["sourcetype"] = new OptionSetValue(0); // 0= database;
                    assemb["isolationmode"] = new OptionSetValue(Convert.ToInt32(attributes[0].ConstructorArguments[7].Value)); // 1= none, 2=sandbox
                    assemb["content"] = Convert.ToBase64String(File.ReadAllBytes(filePath));
                    assemblyId = Service.Create(assemb);
                    sw.WriteLine("Assembly created with id: {0}", assemblyId);
                }
                else
                {
                    string isDelete;
                    Console.WriteLine("Assembly already exists, if you want to delete it kindly enter YES else NO:");
                    isDelete = Console.ReadLine();

                    if (isDelete != "YES" && isDelete != "Yes" && isDelete != "yes" && (isDelete == "NO" || isDelete == "no" || isDelete == "No"))
                    {
                        sw.Write("\r\n");
                        sw.WriteLine("Updating the Assembly with below detail: ");
                        sw.WriteLine("Name: " + props[0].ToString());
                        sw.WriteLine("Version: " + props[2].ToString());
                        sw.WriteLine("IsolationMode: " + attributes[0].ConstructorArguments[7].Value.ToString());
                        sw.WriteLine("Publickeytoken: " + props[6].ToString());

                        Entity assemb = new Entity("pluginassembly");
                        assemb.Id = isAssembly.Id;
                        assemb["name"] = props[0];
                        assemb["culture"] = props[4];
                        assemb["version"] = props[2];
                        assemb["publickeytoken"] = props[6];
                        assemb["sourcetype"] = new OptionSetValue(0); // 0= database;
                        assemb["isolationmode"] = new OptionSetValue(Convert.ToInt32(attributes[0].ConstructorArguments[7].Value)); // 1= none, 2=sandbox
                        assemb["content"] = Convert.ToBase64String(File.ReadAllBytes(filePath));
                        Service.Update(assemb);
                        assemblyId = isAssembly.Id;
                        sw.WriteLine("Updated the assembly");
                    }
                    else
                    {

                        unRegisterPlugin(Service, isAssembly.Id, isAssemblyNameExist);
                        sw.WriteLine("Succesfully deleted the Plugin Assembly");
                        Console.WriteLine("Succesfully deleted the Plugin Assembly");
                        System.Environment.Exit(0);

                    }


                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return assemblyId;
        }
        public static Guid RegisterPlugin(IOrganizationService Service, Guid assemblyId, Assembly Assembly, Type Plugin, int count)
        {
            sw.WriteLine("\r\n");
            sw.WriteLine("-------Register Plugin-------{0}", count);
            Guid pluginTypeId = Guid.Empty;
            sw.WriteLine("Checking if plugin already exists with name: {0}", Plugin.FullName);
            Entity isPluginExist = IsPluginExists(Service, Plugin.FullName, assemblyId);
            if (isPluginExist == null)
            {
                sw.WriteLine("Creating Plugin with below details: ");
                sw.WriteLine("Name: " + Plugin.FullName.ToString());
                sw.WriteLine("Friendly name: " + Plugin.FullName.ToString());
                sw.WriteLine("Type name: " + Plugin.FullName.ToString());

                Entity pluginType = new Entity("plugintype");
                pluginType["pluginassemblyid"] = new EntityReference("pluginassembly", assemblyId);
                pluginType["typename"] = Plugin.FullName;
                pluginType["friendlyname"] = Plugin.FullName;
                pluginType["name"] = Plugin.FullName;
                pluginType["description"] = " Sample Plugin Dynamically";
                pluginTypeId = Service.Create(pluginType);
                sw.WriteLine("Plugin created with id: {0}", pluginTypeId);
            }
            else
            {
                sw.WriteLine("\r\n");
                sw.WriteLine("Updating the Plugin with below details: ");
                sw.WriteLine("Name: " + Plugin.FullName.ToString());
                sw.WriteLine("Friendly name: " + Plugin.FullName.ToString());
                sw.WriteLine("Type name: " + Plugin.FullName.ToString());

                Entity updatePluginType = new Entity("plugintype");
                updatePluginType.Id = isPluginExist.Id;
                updatePluginType["typename"] = Plugin.FullName;
                updatePluginType["friendlyname"] = Plugin.FullName;
                updatePluginType["name"] = Plugin.FullName;
                Service.Update(updatePluginType);
                pluginTypeId = isPluginExist.Id;
                sw.WriteLine("Updated the Plugin");
            }
            return pluginTypeId;
        }
        public static void RegisterPluginStep(IOrganizationService Service, Guid pluginTypeId, Assembly assembly, Type Plugin)
        {
            string assemblyName = assembly.GetName().FullName;
            var pluginTypes = assembly.DefinedTypes;
            Type t = assembly.GetType(Plugin.FullName);
            System.Reflection.MemberInfo info = t;
            var attributes = info.GetCustomAttributesData();
            string imageTarget = string.Empty;
            for (int i = 0; i < attributes.Count; i++)
            {
                sw.WriteLine("\r\n");
                sw.WriteLine("-------Register Plugin Step-------");
                var parametrs = attributes[i].ConstructorArguments;
                string message = parametrs[0].Value.ToString();
                string entityLogicalName = parametrs[1].Value.ToString();
                Guid messageId = PluginMessageId(Service, message);
                string objectTypeCode = getEntityMetadata(entityLogicalName, Service);
                Guid messageFitlerId = MessageFilterId(Service, messageId, objectTypeCode);
                string customName = parametrs[5].Value.ToString();
                string name = customName;
                if (customName == null)
                    name = getStepName(Plugin, entityLogicalName, message);
                sw.WriteLine("Checking if Step already present in the system");
                Guid isStepId = getStepIds(pluginTypeId, Service, name);
                if (isStepId == Guid.Empty || isStepId == null)
                {

                    sw.WriteLine("Creating plugin step with below details: ");
                    sw.WriteLine("Name: " + name);
                    sw.WriteLine("Entity: " + entityLogicalName);
                    sw.WriteLine("Message: " + message);
                    if (Convert.ToInt32(parametrs[3].Value) == 1)
                        sw.WriteLine("Mode: Asynchronous");
                    else
                        sw.WriteLine("Mode: Synchronous");
                    if (Convert.ToInt32(parametrs[2].Value) == 10)
                        sw.WriteLine("Stage: PreValidation");
                    else if (Convert.ToInt32(parametrs[2].Value) == 20)
                        sw.WriteLine("Stage: PreOperation");
                    else
                        sw.WriteLine("Stage: PostOperation");

                    Entity step = new Entity("sdkmessageprocessingstep");
                    step["name"] = name;
                    step["filteringattributes"] = parametrs[4].Value.ToString();
                    step["invocationsource"] = new OptionSetValue(0);
                    step["sdkmessageid"] = new EntityReference("sdkmessage", messageId);
                    step["supporteddeployment"] = new OptionSetValue(0);
                    step["plugintypeid"] = new EntityReference("plugintype", pluginTypeId);
                    step["mode"] = new OptionSetValue(Convert.ToInt32(parametrs[3].Value)); //asy ,syc
                    step["rank"] = 1;
                    step["stage"] = new OptionSetValue(Convert.ToInt32(parametrs[2].Value));//pre,post
                    step["sdkmessagefilterid"] = new EntityReference("sdkmessagefilter", messageFitlerId);
                    Guid stepId = Service.Create(step);
                    sw.WriteLine("Plugin Step created with id and name: {0}", stepId);
                    int c = parametrs.Count;
                    if (c > 8)
                    {
                        if (message == "Create")
                            imageTarget = "id";
                        else if (message == "SetStateDynamicEntity" || message == "SetState")
                            imageTarget = "EntityMoniker";
                        else if (message == "Update")
                            imageTarget = "Target";
                        else
                            imageTarget = "EmailId";
                        int imageType = Convert.ToInt32(parametrs[9].Value);
                        string imageName = parametrs[8].Value.ToString();
                        string imageAttributes = parametrs[10].Value.ToString();
                        CreateImage(stepId, Service, imageType, imageName, imageAttributes, imageTarget);
                    }
                }
                else
                {
                    sw.WriteLine("\r\n");
                    sw.WriteLine("Updating the Step with below details: ");
                    sw.WriteLine("Name: " + name);
                    sw.WriteLine("Entity: " + entityLogicalName);
                    sw.WriteLine("Message: " + message);
                    if (Convert.ToInt32(parametrs[3].Value) == 1)
                        sw.WriteLine("Mode: Asynchronous");
                    else
                        sw.WriteLine("Mode: Synchronous");
                    if (Convert.ToInt32(parametrs[2].Value) == 10)
                        sw.WriteLine("Stage: PreValidation");
                    else if (Convert.ToInt32(parametrs[2].Value) == 20)
                        sw.WriteLine("Stage: PreOperation");
                    else
                        sw.WriteLine("Stage: PostOperation");

                    if (message == "Create")
                        imageTarget = "id";
                    else if (message == "SetStateDynamicEntity" || message == "SetState")
                        imageTarget = "EntityMoniker";
                    else if (message == "Update")
                        imageTarget = "Target";
                    else
                        imageTarget = "EmailId";
                    Entity step = new Entity("sdkmessageprocessingstep");
                    step.Id = isStepId;
                    step["name"] = name;
                    step["filteringattributes"] = parametrs[4].Value.ToString();
                    step["invocationsource"] = new OptionSetValue(0);
                    step["sdkmessageid"] = new EntityReference("sdkmessage", messageId);
                    step["supporteddeployment"] = new OptionSetValue(0);
                    step["plugintypeid"] = new EntityReference("plugintype", pluginTypeId);
                    step["mode"] = new OptionSetValue(Convert.ToInt32(parametrs[3].Value)); //asy ,syc
                    step["rank"] = 1;
                    step["stage"] = new OptionSetValue(Convert.ToInt32(parametrs[2].Value));//pre,post
                    step["sdkmessagefilterid"] = new EntityReference("sdkmessagefilter", messageFitlerId);
                    Service.Update(step);
                    sw.WriteLine("Plugin Step updated");

                    int c = parametrs.Count;
                    if (c > 8)
                    {
                        int imageType = Convert.ToInt32(parametrs[9].Value);
                        string imageName = parametrs[8].Value.ToString();
                        string imageAttributes = parametrs[10].Value.ToString();
                        CreateImage(isStepId, Service, imageType, imageName, imageAttributes, imageTarget);
                    }

                }
            }


        }
        public static void CreateImage(Guid stepId, IOrganizationService service, int imageType, string imageName, string imageAttributes, string imageTarget)
        {

            string[] myValues = new string[] { };
            sw.WriteLine("\r\n");
            sw.WriteLine("Checking if Image already present in the system");
            Guid isImageId = getImageIds(stepId, service);
            if (isImageId == Guid.Empty || isImageId == null)
            {

                sw.WriteLine("Creating image with below details: ");
                sw.WriteLine("Image name: " + imageName);
                if (imageType == 0)
                    sw.WriteLine("Image type: PreImage");
                else
                    sw.WriteLine("Image type: PostImage");
                sw.WriteLine("Image attribute: " + imageAttributes.ToString());

                Entity image = new Entity("sdkmessageprocessingstepimage");
                image["messagepropertyname"] = imageTarget;
                image["imagetype"] = new OptionSetValue(imageType);
                image["entityalias"] = imageName;
                image["name"] = imageName;
                image["attributes"] = imageAttributes;
                image["sdkmessageprocessingstepid"] = new EntityReference("sdkmessageprocessingstep", stepId);
                Guid imageId = service.Create(image);
                sw.WriteLine("Image created with id : {0}", imageId);
            }
            else
            {
                sw.WriteLine("\r\n");
                sw.WriteLine("Updating the Image with below details: ");
                sw.WriteLine("Image name: " + imageName);
                if (imageType == 0)
                    sw.WriteLine("Image type: PreImage");
                else
                    sw.WriteLine("Image type: PostImage");
                sw.WriteLine("Image attribute: " + imageAttributes.ToString());

                Entity image = new Entity("sdkmessageprocessingstepimage");
                image.Id = isImageId;
                image["messagepropertyname"] = imageTarget;
                image["imagetype"] = new OptionSetValue(imageType);
                image["entityalias"] = imageName;
                image["name"] = imageName;
                image["attributes"] = imageAttributes;
                image["sdkmessageprocessingstepid"] = new EntityReference("sdkmessageprocessingstep", stepId);
                service.Update(image);
                sw.WriteLine("Image updated");

            }
        }
        public static Entity IsPluginAssemblyExists(IOrganizationService service, string name)
        {

            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "  <entity name='pluginassembly'>" +
                            "    <attribute name='name' />" +
                            "    <attribute name='sourcetype' />" +
                            "    <attribute name='version' />" +
                            "    <attribute name='culture' />" +
                            "    <attribute name='publickeytoken' />" +
                            "    <attribute name='modifiedby' />" +
                            "    <attribute name='modifiedon' />" +
                            "    <attribute name='path' />" +
                             "    <attribute name='isolationmode' />" +
                            "    <attribute name='pluginassemblyid' />" +
                            "    <filter type='and'>" +
                            "      <condition attribute='name' operator='eq' value='" + name + "' />" +
                            "    </filter>" +
                            "  </entity>" +
                            "</fetch>";
            EntityCollection assembly = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (assembly.Entities.Count > 0)
            {
                sw.WriteLine("Assembly already present in the system with id: {0}", assembly.Entities[0].Id);
                sw.WriteLine("Existing Assembly detail: ");
                sw.WriteLine("Name: " + assembly.Entities[0].Attributes["name"].ToString());
                sw.WriteLine("Version: " + assembly.Entities[0].Attributes["version"].ToString());
                sw.WriteLine("Isolationmode: " + ((OptionSetValue)assembly.Entities[0].Attributes["isolationmode"]).Value.ToString());
                sw.WriteLine("Publickeytoken: " + assembly.Entities[0].Attributes["publickeytoken"].ToString());
                return assembly.Entities[0];

            }
            else
                return null;
        }
        private static Type[] GetPluginTypes(Assembly assembly)
        {

            var query = from type in assembly.GetTypes()

                        where !type.IsInterface
                        where !type.IsAbstract
                        where typeof(IPlugin).IsAssignableFrom(type)
                        select type;

            return query.ToArray();

        }
        public static Entity IsPluginExists(IOrganizationService service, string PluginName, Guid assemblyId)
        {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "  <entity name='plugintype'>" +
                            "    <attribute name='plugintypeid' />" +
                            "    <attribute name='friendlyname' />" +
                            "    <attribute name='name' />" +
                            "    <attribute name='typename' />" +
                            "    <attribute name='pluginassemblyid' />" +
                            "    <attribute name='isworkflowactivity' />" +
                            "    <attribute name='assemblyname' />" +
                            "    <order attribute='friendlyname' descending='false' />" +
                            "    <filter type='and'>" +
                            "      <condition attribute='pluginassemblyid' operator='eq' uiname='PluginAssembly' uitype='pluginassembly' value='" + assemblyId + "' />" +
                            "      <condition attribute='typename' operator='eq' value='" + PluginName + "' />" +
                            "    </filter>" +
                            "  </entity>" +
                            "</fetch>";
            EntityCollection pluginType = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (pluginType.Entities.Count > 0)
            {

                sw.WriteLine("Plugin already present in the system with id: {0}", pluginType.Entities[0].Id);
                sw.WriteLine("Existing Plugin detail: ");
                sw.WriteLine("Name: " + pluginType.Entities[0].Attributes["name"].ToString());
                sw.WriteLine("Friendly name: " + pluginType.Entities[0].Attributes["friendlyname"].ToString());
                sw.WriteLine("Type name: " + pluginType.Entities[0].Attributes["friendlyname"].ToString());

                return pluginType.Entities[0];

            }
            else
                return null;
        }
        public static Guid PluginMessageId(IOrganizationService service, string Messagename)
        {
            Guid messageId = Guid.Empty;
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "  <entity name='sdkmessage'>" +
                            "    <attribute name='name' />" +
                            "    <attribute name='autotransact' />" +
                            "    <attribute name='categoryname' />" +
                            "    <attribute name='expand' />" +
                            "    <attribute name='template' />" +
                            "    <filter type='and'>" +
                            "      <condition attribute='name' operator='eq' value='" + Messagename + "' />" +
                            "    </filter>" +
                            "  </entity>" +
                            "</fetch>";
            EntityCollection message = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (message.Entities.Count > 0)
            {
                messageId = message.Entities[0].Id;

            }
            return messageId;
        }
        public static Guid MessageFilterId(IOrganizationService service, Guid messageId, string objectTypeCode)
        {
            Guid messageFilterId = Guid.Empty;
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                        "  <entity name='sdkmessagefilter'>" +
                        "    <attribute name='sdkmessageid' />" +
                        "    <attribute name='primaryobjecttypecode' />" +
                        "    <attribute name='secondaryobjecttypecode' />" +
                        "    <attribute name='availability' />" +
                        "    <attribute name='iscustomprocessingstepallowed' />" +
                        "    <filter type='and'>" +
                        "      <condition attribute='sdkmessageid' operator='eq' uiname='Create' uitype='sdkmessage' value='" + messageId + "' />" +
                         "      <condition attribute='primaryobjecttypecode' operator='eq' value='" + objectTypeCode + "' />" +
                        "    </filter>" +
                        "  </entity>" +
                        "</fetch>";
            EntityCollection messageFilter = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (messageFilter.Entities.Count > 0)
            {
                messageFilterId = messageFilter.Entities[0].Id;

            }
            return messageFilterId;
        }
        public static string getStepName(Type pluginType, string entityName, string message)
        {

            string pluginName = pluginType.FullName;
            const string format = "{0}:{1} of {2}";
            string stepName = String.Format(format, pluginName, message, entityName);
            return stepName;

        }
        private static string getEntityMetadata(string logicalName, IOrganizationService service)
        {

            if (logicalName == null)
            {

                return null;

            }
            Entity entity = new Entity(logicalName);
            RetrieveEntityRequest EntityRequest = new RetrieveEntityRequest();
            EntityRequest.LogicalName = entity.LogicalName;
            EntityRequest.EntityFilters = EntityFilters.All;
            RetrieveEntityResponse responseent = (RetrieveEntityResponse)service.Execute(EntityRequest);
            EntityMetadata ent = (EntityMetadata)responseent.EntityMetadata;
            string ObjectTypeCode = ent.ObjectTypeCode.ToString();
            return ObjectTypeCode;

        }
        public static Guid getStepIds(Guid pluginId, IOrganizationService service, string name)
        {
            Guid stepId = Guid.Empty;
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                    "  <entity name='sdkmessageprocessingstep'>" +
                    "    <attribute name='name' />" +
                    "    <attribute name='mode' />" +
                    "    <attribute name='stage' />" +
                    "    <attribute name='impersonatinguserid' />" +
                    "    <attribute name='supporteddeployment' />" +
                    "    <attribute name='statuscode' />" +
                    "    <attribute name='statecode' />" +
                    "    <attribute name='sdkmessagefilterid' />" +
                    "    <attribute name='sdkmessageid' />" +
                    "    <attribute name='filteringattributes' />" +
                    "    <attribute name='configuration' />" +
                    "    <attribute name='asyncautodelete' />" +
                    "    <filter type='and'>" +
                    "      <condition attribute='name' operator='eq' value='" + name + "' />" +
                    "      <condition attribute='plugintypeid' operator='eq' value='" + pluginId + "' />" +
                    "    </filter>" +
                    "    <link-entity name='sdkmessagefilter' from='sdkmessagefilterid' to='sdkmessagefilterid' visible='false' link-type='outer' alias='a1'>" +
                    "      <attribute name='secondaryobjecttypecode' />" +
                    "      <attribute name='primaryobjecttypecode' />" +
                    "    </link-entity>" +
                    "   <link-entity name='sdkmessage' from='sdkmessageid' to='sdkmessageid' link-type='inner' alias='aa'>" +
                    "      <attribute name='name' />" +
                    "    </link-entity>" +
                    "  </entity>" +
                    "</fetch>";
            EntityCollection step = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (step.Entities.Count > 0)
            {
                sw.WriteLine("Step already present in the system with id: {0}", step.Entities[0].Id);
                sw.WriteLine("Existing Step detail: ");
                int stepMode = ((OptionSetValue)step.Entities[0].Attributes["mode"]).Value;
                int stepStage = ((OptionSetValue)step.Entities[0].Attributes["stage"]).Value;
                sw.WriteLine("Name: " + step.Entities[0].Attributes["name"]);
                sw.WriteLine("Entity: " + ((AliasedValue)(step.Entities[0].Attributes["a1.primaryobjecttypecode"])).Value);
                sw.WriteLine("Message: " + ((AliasedValue)(step.Entities[0].Attributes["aa.name"])).Value);
                if (stepMode == 1)
                    sw.WriteLine("Mode: Asynchronous");
                else
                    sw.WriteLine("Mode: Synchronous");
                if (stepStage == 10)
                    sw.WriteLine("Stage: PreValidation");
                else if (stepStage == 20)
                    sw.WriteLine("Stage: PreOperation");
                else
                    sw.WriteLine("Stage: PostOperation");
                stepId = step.Entities[0].Id;

            }
            return stepId;

        }
        public static Guid getImageIds(Guid stepId, IOrganizationService service)
        {
            Guid imageId = Guid.Empty;
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                          "  <entity name='sdkmessageprocessingstepimage'>" +
                          "    <attribute name='sdkmessageprocessingstepimageid' />" +
                          "    <attribute name='relatedattributename' />" +
                          "    <attribute name='messagepropertyname' />" +
                          "    <attribute name='imagetype' />" +
                          "    <attribute name='name' />" +
                          "    <attribute name='attributes' />" +
                          "    <link-entity name='sdkmessageprocessingstep' from='sdkmessageprocessingstepid' to='sdkmessageprocessingstepid' link-type='inner' alias='a_177'>" +
                          "      <attribute name='sdkmessageid' />" +
                          "      <attribute name='description' />" +
                          "      <filter type='and'>" +
                          "        <condition attribute='sdkmessageprocessingstepid' operator='eq' value='" + stepId + "' />" +
                          "      </filter>" +
                          "    </link-entity>" +
                          "  </entity>" +
                          "</fetch>";
            EntityCollection step = service.RetrieveMultiple(new FetchExpression(fetchXml));
            if (step.Entities.Count > 0)
            {
                int imageTypes = ((OptionSetValue)step.Entities[0].Attributes["imagetype"]).Value;
                sw.WriteLine("Image already present in the system with id: {0}", step.Entities[0].Id);
                sw.WriteLine("Existing Image detail: ");
                sw.WriteLine("Image name: " + step.Entities[0].Attributes["name"]);
                if (imageTypes == 0)
                    sw.WriteLine("Image type: PreImage");
                else
                    sw.WriteLine("Image type: PostImage");
                sw.WriteLine("Image attribute: " + step.Entities[0].Attributes["attributes"].ToString());
                imageId = step.Entities[0].Id;

            }
            return imageId;
        }
        public static void unRegisterPlugin(IOrganizationService service, Guid assemblyId, string pluginName)
        {
            //List<string> idList = new List<string>();
            //idList.Add(assemblyId.ToString());
            sw.WriteLine("----------------Deleting-------------------");
            Console.WriteLine("----------------Deleting-------------------");
            EntityCollection isPluginExist = getPluginIds(service, assemblyId);
            if (isPluginExist != null || isPluginExist.Entities.Count > 0)
            {
                for (int i = 0; i < isPluginExist.Entities.Count; i++)
                {
                    EntityCollection stepId = getStepIds(service, isPluginExist[i].Id);
                    if (stepId != null || stepId.Entities.Count > 0)
                    {
                        for (int j = 0; j < stepId.Entities.Count; j++)
                        {
                            Guid imageId = getImageIds(stepId[j].Id, service);
                            if (imageId != Guid.Empty)
                            {
                                sw.WriteLine("Deleting the Image with id: " + imageId);
                                Console.WriteLine("Deleting the Image with id: " + imageId);

                                service.Delete("sdkmessageprocessingstepimage", imageId);

                                sw.WriteLine("Deleting the Step with id: " + stepId[j].Id);
                                Console.WriteLine("Deleting the Step with id: " + stepId[j].Id);
                                service.Delete("sdkmessageprocessingstep", stepId[j].Id);
                            }
                            else
                            {
                                sw.WriteLine("Deleting the Step with id: " + stepId[j].Id);
                                Console.WriteLine("Deleting the Step with id: " + stepId[j].Id);

                                service.Delete("sdkmessageprocessingstep", stepId[j].Id);
                            }
                        }
                    }
                    sw.WriteLine("Deleting the Plugin with id: " + isPluginExist[i].Id);
                    Console.WriteLine("Deleting the Plugin with id: " + isPluginExist[i].Id);

                    service.Delete("plugintype", isPluginExist[i].Id);
                }

            }
            sw.WriteLine("Deleting the assembly with id: " + assemblyId);
            Console.WriteLine("Deleting the assembly with id: " + assemblyId);

            service.Delete("pluginassembly", assemblyId);


        }



        private static EntityCollection getStepIds(IOrganizationService service, Guid pluginId)
        {

            QueryExpression query = new QueryExpression("sdkmessageprocessingstep");
            query.Criteria.AddCondition(

            "plugintypeid",
            ConditionOperator.Equal,
            pluginId.ToString());

            EntityCollection entities = service.RetrieveMultiple(query);
            return entities;
            //  return entities.Entities.Select(e => e.Id).ToArray();

        }
        private static EntityCollection getPluginIds(IOrganizationService service, Guid assemblyId)
        {

            QueryExpression query = new QueryExpression("plugintype");
            query.Criteria.AddCondition(

        "pluginassemblyid",
            ConditionOperator.Equal,
            assemblyId.ToString());

            EntityCollection entities = service.RetrieveMultiple(query);
            return entities;
            // return entities.Entities.Select(e => e.Id).ToArray();

        }

        private static void ShowAttributeData(
        IList<CustomAttributeData> attributes)
        {
            foreach (CustomAttributeData cad in attributes)
            {

                foreach (CustomAttributeTypedArgument cata
                    in cad.ConstructorArguments)
                {
                    //cad.ConstructorArguments[0].Value
                    ShowValueOrArray(cata);
                }

                //Console.WriteLine("      Named arguments:");
                //foreach (CustomAttributeNamedArgument cana
                //    in cad.NamedArguments)
                //{
                //    Console.WriteLine("         MemberInfo: '{0}'",
                //        cana.MemberInfo);
                //    ShowValueOrArray(cana.TypedValue);
                //}
            }
        }
        private static void ShowValueOrArray(CustomAttributeTypedArgument cata)
        {

            Console.WriteLine("Type: '{0}'  Value: '{1}'",
                cata.ArgumentType, cata.Value);

        }

        public static void RKY_PingTest()
        {
            Console.WriteLine("RKY_APRT is working successfully");
        }
        public static IOrganizationService LoginToCrm()
        {
            string connectionString;
            IOrganizationService orgService;
            CrmServiceClient conn;
            connectionString = "Url=" + ConfigurationManager.AppSettings["CRMUrl"] + "; Username=" + ConfigurationManager.AppSettings["CRMName"] + "; Password=" + ConfigurationManager.AppSettings["CRMPass"] + "; authtype=Office365";
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            conn = new CrmServiceClient(connectionString);
            conn.OrganizationServiceProxy.Timeout = new TimeSpan(0, 5, 0);

            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = ConfigurationManager.AppSettings["CRMName"];
            clientCredentials.UserName.Password = ConfigurationManager.AppSettings["CRMPass"];

            //orgService = (IOrganizationService)new OrganizationServiceProxy(new Uri(ConfigurationManager.AppSettings["CRMUrl"]),
             //    null, clientCredentials, null);
            //((OrganizationServiceProxy)orgService).Timeout = new TimeSpan(0, 3, 0);
            return null;


        }
    }
}

